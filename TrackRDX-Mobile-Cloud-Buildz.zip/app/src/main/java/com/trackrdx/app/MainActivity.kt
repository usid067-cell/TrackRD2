package com.trackrdx.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val navy = Color(0xFF101A2C)
private val panel = Color(0xFF1B2940)
private val mint = Color(0xFF53D6B5)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { App() } }
}

@Composable fun App() {
    var page by remember { mutableStateOf("Overview") }
    val tabs = listOf("Overview", "Devices", "Screen Time", "Apps", "Reports", "Settings")
    MaterialTheme(colorScheme = darkColorScheme(primary = mint, background = navy, surface = panel, onBackground = Color.White, onSurface = Color.White)) {
        Column(Modifier.fillMaxSize().background(navy).padding(16.dp)) {
            Text("TrackRDX", fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Text("Family device dashboard", color = Color.LightGray, fontSize = 13.sp)
            Spacer(Modifier.height(16.dp))
            tabs.chunked(3).forEach { group ->
                Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                    group.forEach { t -> FilterChip(selected = page == t, onClick = { page = t }, label = { Text(t, fontSize = 10.sp) }) }
                }
            }
            Spacer(Modifier.height(14.dp))
            when (page) {
                "Overview" -> LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    item { Metric("Devices", "0", "Waiting for family devices") }
                    item { Metric("Screen time today", "--", "No device data connected") }
                    item { Metric("App activity", "--", "Usage access not configured") }
                    item { Card(colors = CardDefaults.cardColors(containerColor = panel)) {
                        Column(Modifier.padding(16.dp)) {
                            Text("Getting started", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            Spacer(Modifier.height(8.dp))
                            Text("1. Install TrackRDX on each Android device.")
                            Text("2. Each device owner reviews and approves sharing.")
                            Text("3. Connect devices to the family dashboard.")
                            Spacer(Modifier.height(8.dp))
                            Text("First build: dashboard preview only. Live monitoring is not enabled.", color = mint, fontSize = 12.sp)
                        }
                    } }
                }
                else -> Column {
                    Text(page, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(10.dp))
                    Text(if (page == "Settings") "Privacy-first sharing" else "No data connected yet", color = mint)
                    Spacer(Modifier.height(8.dp))
                    Text("This section will show information after the device owner completes setup and grants the relevant permission.", color = Color.LightGray)
                }
            }
        }
    }
}

@Composable private fun Metric(title: String, value: String, note: String) {
    Card(colors = CardDefaults.cardColors(containerColor = panel), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.fillMaxWidth().padding(16.dp)) {
            Text(title, color = Color.LightGray, fontSize = 13.sp)
            Text(value, fontSize = 30.sp, fontWeight = FontWeight.Bold)
            Text(note, color = Color.LightGray, fontSize = 12.sp)
        }
    }
}
