TrackRDX — mobile-only cloud build starter

IMPORTANT: This first build is a dashboard UI preview only. It does NOT collect live
screen time, app inventory, GPS location, or background activity yet.

Build using your phone:
1. Open github.com in your phone browser and sign in.
2. Create a repository named TrackRDX.
3. Upload the CONTENTS of this folder into the repository (not the ZIP itself).
   Include the hidden .github/workflows/android.yml file.
4. Open the repository's Actions tab.
5. Run "Build TrackRDX APK" (or wait for the automatic build after upload).
6. Open the successful run and download the "TrackRDX-debug-apk" artifact.
7. Extract the downloaded ZIP on your phone and install app-debug.apk.
   Android may ask you to allow installs from your browser or file manager.

Next: implement opt-in Android Usage Access, installed-app inventory, and optional
location sharing. Each family member must approve data sharing on their own device.
